
#####################
  The FileBrowser API
#####################

:mod:`filebrowser`
==============================

.. automodule:: __init__
   :members:
   :show-inheritance:
